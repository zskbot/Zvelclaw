// nav.js — dùng chung cho mọi trang.
// Tự động gắn class "active" + aria-current cho link topnav khớp với trang đang mở.
(function () {
  var current = location.pathname.split('/').pop() || 'index.html';

  document.querySelectorAll('.navlinks a').forEach(function (link) {
    var href = link.getAttribute('href');
    var isActive = href === current || (current === '' && href === 'index.html');
    link.classList.toggle('active', isActive);
    if (isActive) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
})();
